repo: KrakenSaten/RIFT
branch: rift-tdeck
path: examples/companion_radio/ui-rift

## Last sync

date: 2026-08-13T16:55:05Z

### Updated in this project

- Read the RIFT UI source (splash, MESH, NODES/constellation, RADAR, waterfall, COMMS, SYSTEM)
- Diagnosed NODES placement (`branch & 15`), 1px link stubs and `drawRect` hop rings
- Diagnosed RADAR scatter angle derived from array index (`i & 15`), unlabelled axes
- Redrew NODES + RADAR on the real 6x8 GFX grid, grounded in `ST7789NativeDisplay`

## Screen map

| Project screen | Repo files |
| --- | --- |
| RIFT skjermdesign.dc.html — 3A NODES/RADAR (hardware pass) | examples/companion_radio/ui-rift/UITask.cpp; src/helpers/ui/ST7789NativeDisplay.h; src/helpers/ui/DisplayDriver.h |
| RIFT skjermdesign.dc.html — NODES (1a/1b/1c) | examples/companion_radio/ui-rift/UITask.cpp (`RiftConstellationScreen`) |
| RIFT skjermdesign.dc.html — RADAR (1a/1b/1c) | examples/companion_radio/ui-rift/UITask.cpp (`RiftRadarScreen`) |
| RIFT skjermdesign.dc.html — RF Waterfall (2c) | examples/companion_radio/ui-rift/UITask.cpp (`RiftRadarScreen::renderWaterfall`) |
| RIFT skjermdesign.dc.html — COMMS (2b) | examples/companion_radio/ui-rift/UITask.cpp (`RiftCommsScreen`) |
| RIFT skjermdesign.dc.html — Splash (2b) | examples/companion_radio/ui-rift/UITask.cpp (`RiftSplashScreen`) |
| RIFT skjermdesign.dc.html — Ordmerke (2a) | logo/ (upstream MeshCore only — no RIFT mark exists) |
| Nav bar / title bar chrome | examples/companion_radio/ui-rift/UITask.cpp (`renderNavBar`, `renderTitleBar`) |

## Sync history

- 2026-08-13T16:20:27Z — confirmed `logo/` holds only upstream MeshCore artwork
- 2026-08-13T16:06:27Z — first read of ui-rift UITask.cpp
